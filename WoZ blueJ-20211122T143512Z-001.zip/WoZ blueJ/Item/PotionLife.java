package Item;

public class PotionLife extends Item{
    public int nblife=1;
    public void use(){
    }
}