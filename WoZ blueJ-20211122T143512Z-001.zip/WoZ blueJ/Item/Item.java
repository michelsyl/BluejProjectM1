package Item;

public abstract class Item {
    public String name;
    public String description;
}