package character;


public class Clues   {
}
