package character;

public class Guard extends Character {

    /**
     * Constructeur
     * @param name
     */
    public Guard(String name,int posx,int posy){
        super(name,posx,posy);
    }
}
